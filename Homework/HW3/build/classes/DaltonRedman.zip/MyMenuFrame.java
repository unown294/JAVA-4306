/*
 * Copyright (C) 2020 Dalton
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

//Import List
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.awt.event.InputEvent.CTRL_DOWN_MASK;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;

/**
 *
 * @author Dalton
 */
public class MyMenuFrame extends JFrame{
    private final JTextArea textArea;
    private final JCheckBoxMenuItem [] styleItems;
    private final JRadioButtonMenuItem [] fonts;
    private final ButtonGroup fontButtonGroup;
    
    public MyMenuFrame() {
        
        super("MyNotepad");
        
        setLayout(new BorderLayout());
        
        JMenu fileMenu = new JMenu ("File");
        fileMenu.setMnemonic('F');
        //Types ALT+F, it will open File menu
        
        //Open File Menu Tab
        JMenuItem openFile = new JMenuItem("Open");
        openFile.setAccelerator(KeyStroke.getKeyStroke('O', CTRL_DOWN_MASK));
        
        fileMenu.add(openFile);
        
        openFile.addActionListener(
            new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fc = new JFileChooser();
        
                int i = fc.showOpenDialog(MyMenuFrame.this);

                if(i == JFileChooser.APPROVE_OPTION){
                    File file = fc.getSelectedFile();

                    try(BufferedReader br = new BufferedReader(new FileReader(file))){

                        
                       //Was Suppressed when used as it was returning only one 
//                        String content = "";
//
//                        while(scanner.hasNextLine()){
//                            content = scanner.nextLine();
//                        }
//
//                        textArea.setText(content);

                          
                        textArea.read(br, "The file was successfully read");

                    } 
                    catch (FileNotFoundException ex) {

                        } catch (IOException ex) {
                        Logger.getLogger(MyMenuFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    }
                
                };
            }
        );
        
        //Seperate Open and Save menu items
        fileMenu.addSeparator();
        
        //Save File menu Item
        JMenuItem saveMenu = new JMenuItem("Save");
        saveMenu.setAccelerator(KeyStroke.getKeyStroke('S', CTRL_DOWN_MASK));
        
        fileMenu.add(saveMenu);
        
        saveMenu.addActionListener(
            new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    JFileChooser fc = new JFileChooser();

                    int answer = fc.showSaveDialog(MyMenuFrame.this);

                    //File openner
                    if(answer == JFileChooser.APPROVE_OPTION){

                        String path = fc.getSelectedFile().getPath();

                        //Part that writes to the file
                        try(FileWriter writer = new FileWriter(path)){

                            writer.write(textArea.getText());

                        } catch (IOException ex) {

                        }
                    }
                }
            }
        );
        
        //Seperates save and exit menu item
        fileMenu.addSeparator();
        
        //Exit Menu Item
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.setAccelerator(KeyStroke.getKeyStroke('X', CTRL_DOWN_MASK));
        
        fileMenu.add(exitItem);
        
        exitItem.addActionListener(
            new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    System.exit(0);
                }
            }
        );
                
        //Edit Menu tab
        JMenu editMenu = new JMenu("Edit");
        editMenu.setMnemonic('D');
        
        //Color Menu
        JMenu colorMenu = new JMenu ("Colors");
        colorMenu.setMnemonic('C');
        
        //Color Menu Item
        JMenuItem colorMenuItem = new JMenuItem("Color");
        colorMenuItem.setAccelerator(KeyStroke.getKeyStroke('C', CTRL_DOWN_MASK));
        colorMenu.add(colorMenuItem);
        
        editMenu.add(colorMenu);
        
        colorMenuItem.addActionListener(
            new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    Color color = JColorChooser.showDialog(textArea, "Select a color", Color.RED);
                    textArea.setForeground(color);
                    //Not updating the textArea
                }
            }
        );
        
        //Adds a seperator between colorMenuItem and fontMenuItem
        editMenu.addSeparator();
        
        //Font Menu Item
        String [] fontNames = {"Times New Roman", "Arial", "Serif"};    //List of desired fonts type wanted, can be expanded
        JMenu fontMenu = new JMenu("Font");
        fontMenu.setMnemonic('F');
        ItemHandler itemHandler = new ItemHandler();
        
        fonts = new JRadioButtonMenuItem[fontNames.length];
        fontButtonGroup = new ButtonGroup();

        //Creates the buttons and button group
        for(int count = 0; count < fontNames.length; count++){
            
            fonts[count] = new JRadioButtonMenuItem(fontNames[count]);
            fontMenu.add(fonts[count]);
            fontButtonGroup.add(fonts[count]);                      //Needed for the radio button to deselect others
            fonts[count].addActionListener(itemHandler);
            
        }
        
        fonts[0].setSelected(false);
        
        //Seperates the font types and font styles
        fontMenu.addSeparator();
        
        String [] styleNames = {"Bold", "Italic"};                  //List of desired font styles, can be expanded if desired
        styleItems = new JCheckBoxMenuItem[styleNames.length];
        StyleHandler styleHandler = new StyleHandler();
        
        //Creates the Check box that can be selected in the menu
        for(int count = 0; count < styleNames.length; count++){
            styleItems[count] = new JCheckBoxMenuItem(styleNames[count]);
            fontMenu.add(styleItems[count]);
            styleItems[count].addItemListener(styleHandler);
        }
        
        editMenu.add(fontMenu);
        //End of Edit Menu
        
        //Print Menu
        JMenu printMenu = new JMenu("Print");
        printMenu.setMnemonic('P');
        
        //Creates the Menu Item
        JMenuItem printItem = new JMenuItem("Send to Printer");
        printItem.setAccelerator(KeyStroke.getKeyStroke('P', CTRL_DOWN_MASK));
        
        //Print Menu Item Action Listener
        printItem.addActionListener(
            new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    int response = JOptionPane.showOptionDialog(MyMenuFrame.this, String.format("Do you want to print this file?"), "Confirmation", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
                    
                    if(response == 0){
                        JOptionPane.showMessageDialog(MyMenuFrame.this ,"This file is succesfully printed", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                    }
                }

            }
        );
        
        printMenu.add(printItem);
        
        //Help Menu
        JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic('H');
        
        //About Menu Item        
        JMenuItem aboutItem = new JMenuItem("About");
        aboutItem.setAccelerator(KeyStroke.getKeyStroke('A', CTRL_DOWN_MASK));
        
        aboutItem.addActionListener(
            new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(MyMenuFrame.this, "This software is developed in 2019\nVersion is 1.0", "About", JOptionPane.INFORMATION_MESSAGE);
                }
                
            }
        );
        helpMenu.add(aboutItem);
        
        //Help Menu seperator between aboutMenuItem and visitMenuItem 
        helpMenu.addSeparator();
        
        //Visit Homepage menu item
        JMenuItem visitItem = new JMenuItem("Visit Homepage");
        visitItem.setAccelerator(KeyStroke.getKeyStroke('V', CTRL_DOWN_MASK));
        
        //Visit Item Action Listener
        visitItem.addActionListener(
            new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    String url = "http://www.microsoft.com";
                    openWebpage(url);
                    //This is the method given by the instructor
                }
            
            }
        );
        helpMenu.add(visitItem);
        
        //Menu Bar builder
        JMenuBar bar = new JMenuBar();
        setJMenuBar(bar);
        bar.add(fileMenu);
        bar.add(editMenu);
        bar.add(printMenu);
        bar.add(helpMenu);
        
        //Generates a new textArea
        textArea = new JTextArea();
        add(textArea, BorderLayout.CENTER);
    }//End of Constructor
    
    private class StyleHandler implements ItemListener{

        @Override
        public void itemStateChanged(ItemEvent e) {
           
            String name = textArea.getFont().getName();
            //Get current font
            Font font;
            
            if(styleItems[0].isSelected() && styleItems[1].isSelected()){
                font = new Font(name, Font.BOLD+Font.ITALIC, 20);
            }
            
            else if(styleItems[0].isSelected()){
                font = new Font(name, Font.BOLD, 20);
            }
            
            else if(styleItems[1].isSelected()){
                font = new Font(name, Font.ITALIC, 20);
            }
            
            else{
                font = new Font(name, Font.PLAIN, 20);
            }
            
            textArea.setFont(font);
            repaint();
        }
    }
    
    private class ItemHandler implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
           
            //Font Selection
            for(int count=0; count < fonts.length; count++){
                if(e.getSource() == fonts[count]){
                    textArea.setFont(new Font(fonts[count].getText(), Font.PLAIN, 20));
                }
            }
            
            repaint();//Redraw the application
        }
    }


    public static void openWebpage (String urlString) {
        try {
            Desktop.getDesktop().browse(new URL(urlString).toURI());
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

}//End of Class